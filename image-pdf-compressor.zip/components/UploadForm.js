import imageCompression from 'browser-image-compression'

export default function UploadForm() {
  const handleImageUpload = async (e) => {
    const file = e.target.files[0]
    const options = { maxSizeMB: 1, maxWidthOrHeight: 1024 }
    const compressed = await imageCompression(file, options)
    const url = URL.createObjectURL(compressed)
    window.open(url)
  }

  return (
    <div>
      <input type="file" accept="image/*" onChange={handleImageUpload} />
    </div>
  )
}
