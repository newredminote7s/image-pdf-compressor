import Head from 'next/head'
import UploadForm from '../components/UploadForm'
import AdSlot from '../components/AdSlot'

export default function Home() {
  return (
    <>
      <Head>
        <title>Free Image & PDF Compressor</title>
        <meta name="description" content="Compress your images and PDF files for free." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <main className="p-4 max-w-3xl mx-auto text-center">
        <h1 className="text-3xl font-bold my-4">Image & PDF Compressor</h1>

        <AdSlot slot="top-banner" />

        <UploadForm />

        <AdSlot slot="bottom-banner" />
      </main>
    </>
  )
}
