# Image & PDF Compressor Tool

Free tool built with Next.js for compressing images and PDFs. Includes AdSense-ready layout.
